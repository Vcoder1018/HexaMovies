package dao;

import java.util.List;
import model.Bookings;
public interface BookingsDAO {

    public List<Bookings> getBookings(String useremail);

    public Bookings getBooking(int bookingid);

    public List<String> getSeats(int showid, int movieid, String showdate);

    public int getTickets(int showtime, int movieid, String showdate);

    public int makeBooking(String email, int movieid, int showid, String bookingdate, String showdate, int tickets, String seats, int price);

}
