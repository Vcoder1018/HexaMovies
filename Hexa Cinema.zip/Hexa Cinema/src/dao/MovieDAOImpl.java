package dao;

import model.Shows;
import model.User;
import model.Movie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MovieDAOImpl implements MoviesDAO {

    @Override
    public List<Movie> getMovieList() {
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from movies";
        List<Movie> list = new ArrayList<Movie>();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int movieid = rs.getInt("idmovies");
                String moviename = rs.getString("name");
                String cast = rs.getString("cast");
                String genre = rs.getString("genre");
                String releaseDate = rs.getString("releaseDate");
                int price = rs.getInt("price");
                String coverUrl = rs.getString("cover");
                list.add(new Movie(movieid, moviename, cast, genre, releaseDate, price, coverUrl));
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Movie getMovie(int movieid) {
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from movies where idmovies = " + movieid;
        Movie m = new Movie();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
//                movieid = rs.getInt("idmovies");
                String moviename = rs.getString("name");
                String cast = rs.getString("cast");
                String genre = rs.getString("genre");
                String releaseDate = rs.getString("releaseDate");
                int price = rs.getInt("price");
                String coverUrl = rs.getString("cover");
                m = new Movie(movieid, moviename, cast, genre, releaseDate, price, coverUrl);
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return m;
    }

    @Override
    public List<Shows> getShows(int movieid){
        List<Shows> showsList = new ArrayList<Shows>();
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from `shows-movies` where movies_idmovies = " + movieid;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int showid = rs.getInt("id");
                int showtime = rs.getInt("shows");
                int movie_id = rs.getInt("movies_idmovies");
                showsList.add(new Shows(showid, showtime, movie_id));
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return showsList;
    }

    @Override
    public int getShow(int showid){
        int showId = 0;
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from `shows-movies` where id = " + showId;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                showId = rs.getInt("id");

            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return showId;
    }

    @Override
    public int getShowid(int movieid, int showtime){
        Connection con = DBConnect.getConnecttion();
        int showid = 0;
        String sql = "select id from `shows-movies` where movies_idmovies = " + movieid + " AND shows = " + showtime;
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                showid = rs.getInt(1);
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return showid;
    }


}
