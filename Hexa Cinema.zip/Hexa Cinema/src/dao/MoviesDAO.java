package dao;
import model.Movie;
import model.Shows;

import java.util.List;

public interface MoviesDAO {

    public List<Movie> getMovieList();

    public Movie getMovie(int movieid);

    public List<Shows> getShows(int movieid);

    public int getShowid(int movieid, int showtime);

}
