package dao;
import model.User;
public interface UserDAO {

    public void addUser(User u);

    public boolean login(String username, String password);

    public User getUser(String username);

    public boolean checkUser(String username);

}
