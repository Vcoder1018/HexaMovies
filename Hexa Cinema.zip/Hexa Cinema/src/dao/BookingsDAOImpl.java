package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import model.Bookings;


public class BookingsDAOImpl implements BookingsDAO{


    @Override
    public List<Bookings> getBookings(String useremail) {
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from bookings where users_email = '" + useremail + "' ";
        Bookings b = new Bookings();
        List<Bookings> bookingsList = new ArrayList<Bookings>();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int bookingid = rs.getInt("iduser-movies");
                String bookinguser = rs.getString("users_email");
                int movieid = rs.getInt("movies_idmovies");
                int showid = rs.getInt("shows-movies_id");
                String bookingdate = rs.getString("bookig-date");
                String showdate = rs.getString("show-date");
                int tickets = rs.getInt("tickets");
                String seats = rs.getString("seats");
                int price = rs.getInt("price");
                bookingsList.add(new Bookings(bookingid, bookinguser, movieid, showid, bookingdate, showdate, tickets, seats, price));


            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return bookingsList;
    }

    @Override
    public Bookings getBooking(int bookingid) {
        Connection con = DBConnect.getConnecttion();
        String sql = "select * from bookings where iduser-movies = '" + bookingid + "' ";
        Bookings b = new Bookings();
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                bookingid = rs.getInt("iduser-movies");
                String bookinguser = rs.getString("users_email");
                int movieid = rs.getInt("movies_idmovies");
                int showid = rs.getInt("shows-movies_id");
                String bookingdate = rs.getString("bookig-date");
                String showdate = rs.getString("show-date");
                int tickets = rs.getInt("tickets");
                String seats = rs.getString("seats");
                int price = rs.getInt("price");
                b = new Bookings(bookingid, bookinguser, movieid, showid, bookingdate, showdate, tickets, seats, price);
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return b;
    }

    @Override
    public List<String> getSeats(int showid, int movieid, String showdate) {
        Connection con = DBConnect.getConnecttion();
        String seats = "";
        List<String> seatsList = new ArrayList<>();

        String sql = "select `seats` from bookings where `movies_idmovies` = "+ movieid +" AND `shows-movies_id` = " + showid + " AND `show-date` like '"+ showdate +"';";
        System.out.println(sql);
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                seats += rs.getString(1).replace(" ", "") + ",";
            }
            con.close();
            seatsList = Arrays.asList(seats.split(","));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return seatsList;
    }

    @Override
    public int getTickets(int showtime, int movieid, String showdate){
        int tickets = 0;
        Connection con = DBConnect.getConnecttion();
        String sql = "select sum(tickets) from bookings where `shows-movies_id` = (select id from `shows-movies` where shows = " + showtime + " AND movies_idmovies = " + movieid + ") AND `show-date` like '" + showdate + "'";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                tickets = rs.getInt(1);
            }
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tickets;
    }

    @Override
    public int makeBooking(String email, int movieid, int showid, String bookingdate, String showdate, int tickets, String seats, int price) {
        Connection con = DBConnect.getConnecttion();
        int rows = 0;
//        String sql = "select sum(tickets) from bookings where `shows-movies_id` = (select id from `shows-movies` where shows = " + showtime + " AND movies_idmovies = " + movieid + ") AND `show-date` like '" + showdate + "'";
        String sql = "INSERT INTO `hexa`.`bookings` (`users_email`, `movies_idmovies`, `shows-movies_id`, `bookig-date`, `show-date`, `tickets`, `seats`, `price`) VALUES ('" + email + "', '" + movieid + "', '"+ showid + "', '" + bookingdate + "', '" + showdate + "', '" + tickets + "', '" + seats + "' , '" + price + "');";
        System.out.println(sql);
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            rows = ps.executeUpdate(sql);

            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rows;
    }
}
