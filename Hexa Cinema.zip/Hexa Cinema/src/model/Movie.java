package model;

import java.util.List;

public class Movie {

    private int movieid;
    private String  moviename;
    private String  cast;
    private String  genre;
    private String  releaseDate;
    private int price;
    private String coverUrl;


    public Movie(){
    }


    public Movie(int id, String name, String cast, String genre, String releaseDate, int price, String coverUrl){
        this.movieid = id;
        this.moviename = name;
        this.cast = cast;
        this.genre = genre;
        this.releaseDate = releaseDate;
        this.price = price;
        this.coverUrl = coverUrl;

    }

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

}
