package model;

public class Shows {
    private int showid;
    private int showtime;
    private int movieid;

    public Shows(){}

    public Shows(int showid, int showtime, int movieid){
        this.showid = showid;
        this.showtime = showtime;
        this.movieid = movieid;
    }

    public int getShowid() {
        return showid;
    }

    public void setShowid(int showid) {
        this.showid = showid;
    }

    public int getShowtime() {
        return showtime;
    }

    public void setShowtime(int showtime) {
        this.showtime = showtime;
    }

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }
}
