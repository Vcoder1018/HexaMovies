package model;

public class User {

    private String useremail;
    private String username;
    private String password;

    public User(){
    }

    public User(String useremail, String username, String password){
        this.useremail = useremail;
        this.username = username;
        this.password = password;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
