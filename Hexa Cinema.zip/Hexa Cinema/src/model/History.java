package model;

public class History {

    int movieid;
    String movieName;
    String showDate;
    String showTime;
    int tickets;
    int price;
    String bookingDate;

    public History(){}

    public History(int movieid, String movieName, String showDate, String showTime, int tickets, int price, String bookingDate){
        this.movieid = movieid;
        this.movieName = movieName;
        this.showDate = showDate;
        this.showTime = showTime;
        this.tickets = tickets;
        this.price = price;
        this.bookingDate = bookingDate;
    }

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getShowDate() {
        return showDate;
    }

    public void setShowDate(String showDate) {
        this.showDate = showDate;
    }

    public String getShowTime() {
        return showTime;
    }

    public void setShowTime(String showTime) {
        this.showTime = showTime;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }
}
