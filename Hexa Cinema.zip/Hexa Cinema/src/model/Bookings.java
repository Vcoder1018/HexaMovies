package model;

public class Bookings {

    private int id;
    private String bookinguser;
    private int movieid;
    private int showid;
    private String bookingdate;
    private String showdate;
    private int tickets;
    private String seats;
    private int price;

    public Bookings(){}

    public Bookings(int id, String bookinguser, int movieid, int showid, String bookingdate, String showdate, int tickets, String seats, int price){
        this.id = id;
        this.bookinguser = bookinguser;
        this.movieid = movieid;
        this.showid = showid;
        this.bookingdate = bookingdate;
        this.showdate = showdate;
        this.tickets = tickets;
        this.seats = seats;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookinguser() {
        return bookinguser;
    }

    public void setBookinguser(String bookinguser) {
        this.bookinguser = bookinguser;
    }

    public int getMovieid() {
        return movieid;
    }

    public void setMovieid(int movieid) {
        this.movieid = movieid;
    }

    public int getShowid() {
        return showid;
    }

    public void setShowid(int showid) {
        this.showid = showid;
    }

    public String getBookingdate() {
        return bookingdate;
    }

    public void setBookingdate(String bookingdate) {
        this.bookingdate = bookingdate;
    }

    public String getShowdate() {
        return showdate;
    }

    public void setShowdate(String showdate) {
        this.showdate = showdate;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public String getSeats() {
        return seats;
    }

    public void setSeats(String seats) {
        this.seats = seats;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
