package controller;

import dao.BookingsDAOImpl;
import dao.MovieDAOImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

public class BookServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        BookingsDAOImpl b = new BookingsDAOImpl();
        MovieDAOImpl m = new MovieDAOImpl();
        String useremail = (String)session.getAttribute("useremail");
        String movieid = (String)session.getAttribute("movieid");
        String showid = (String)session.getAttribute("showid");
        String bookingdate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        String showdate = (String)session.getAttribute("showdate");

        String[] selectedTickets = req.getParameterValues("check");
        int tickets = selectedTickets.length;
        String seats = Arrays.toString(selectedTickets).replace("[", "").replace("]", "").replace(" ", "");
        int price = tickets * m.getMovie(Integer.parseInt((String)session.getAttribute("movieid"))).getPrice();
        String moviename = m.getMovie(Integer.parseInt(movieid)).getMoviename();
        session.setAttribute("moviename", moviename);
        System.out.println(bookingdate + " :: " +showdate);
        String seatString = Arrays.toString(selectedTickets).replace("[", "").replace("]","");
        session.setAttribute("seatString", seatString);
        b.makeBooking(useremail,Integer.parseInt(movieid),Integer.parseInt(showid),bookingdate,showdate,tickets,seats,price);
        resp.sendRedirect("confirmbooking.jsp");
        System.out.println(tickets);

    }
}
