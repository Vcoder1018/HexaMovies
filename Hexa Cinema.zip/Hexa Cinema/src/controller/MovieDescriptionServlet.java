package controller;

import dao.MovieDAOImpl;
import model.Movie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


public class MovieDescriptionServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession();

        MovieDAOImpl movieDAO = new MovieDAOImpl();
        int movieid = Integer.parseInt(req.getParameter("movieid"));
        Movie m = movieDAO.getMovie(movieid);

        String moviename = m.getMoviename();
        String cast = m.getCast();
        String genre = m.getGenre();
        String releaseDate = m.getReleaseDate();
        String price = Integer.toString(m.getPrice());
        String coverUrl = m.getCoverUrl();

        session.setAttribute("movieid", Integer.toString(movieid));
        session.setAttribute("moviename", moviename);
        session.setAttribute("cast", cast);
        session.setAttribute("genre", genre);
        session.setAttribute("releaseDate", releaseDate);
        session.setAttribute("price", price);
        session.setAttribute("coverUrl", coverUrl);

        resp.sendRedirect("moviedescription.jsp");
    }
}
