package controller;

import dao.MovieDAOImpl;
import model.Movie;
import model.Shows;
import model.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

public class MovieDescriptionServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();

        MovieDAOImpl movieDAO = new MovieDAOImpl();
        int movieid = Integer.parseInt(req.getParameter("movieid"));
        Movie m = movieDAO.getMovie(movieid);

        String moviename = m.getMoviename();
        String cast = m.getCast();
        String genre = m.getGenre();
        String releaseDate = m.getReleaseDate();
        String price = Integer.toString(m.getPrice());
        String coverUrl = m.getCoverUrl();

        List<Shows> shows = movieDAO.getShows(movieid);

        session.setAttribute("movieid", Integer.toString(movieid));
        session.setAttribute("moviename", moviename);
        session.setAttribute("cast", cast);
        session.setAttribute("genre", genre);
        session.setAttribute("releaseDate", releaseDate);
        session.setAttribute("price", price);
        session.setAttribute("coverUrl", coverUrl);

        resp.sendRedirect("moviedescription.jsp");
    }
}
