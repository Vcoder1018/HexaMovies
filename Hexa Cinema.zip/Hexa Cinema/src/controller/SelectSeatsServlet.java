package controller;

import dao.BookingsDAOImpl;
import dao.MovieDAOImpl;
import model.Movie;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;

public class SelectSeatsServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        MovieDAOImpl m = new MovieDAOImpl();
        BookingsDAOImpl b = new BookingsDAOImpl();
        String showtime = req.getParameter("time");
        String showdate = req.getParameter("showDate");
        String err = "";
        if (showdate.equals("")){
            err = "Please select the date.";
            session.setAttribute("dateErr", err);
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/moviedescription.jsp");
            rd.forward(req, resp);
        }
        else {

            String useremail = (String) session.getAttribute("useremail");
            String movieid = (String) session.getAttribute("movieid");
            int showid = m.getShowid(Integer.parseInt(movieid), Integer.parseInt(showtime));
            java.util.Date date = new java.util.Date();
            java.sql.Date bookingdate = new java.sql.Date(date.getTime());
            int tickets = b.getTickets(Integer.parseInt(showtime), Integer.parseInt(movieid), showdate);
            List<String> seats = b.getSeats(showid, Integer.parseInt(movieid), showdate);
            int price = m.getMovie(Integer.parseInt(movieid)).getPrice() * tickets;


            session.setAttribute("showtime", showtime);
            session.setAttribute("showdate", showdate);
            session.setAttribute("movieid", movieid);
            session.setAttribute("showid", Integer.toString(showid));
            session.setAttribute("bookingdate", bookingdate);
            session.setAttribute("tickets", Integer.toString(tickets));
            session.setAttribute("seatsList", seats);
            session.setAttribute("price", Integer.toString(price));

            resp.sendRedirect("selectseats.jsp");
        }
    }
}
